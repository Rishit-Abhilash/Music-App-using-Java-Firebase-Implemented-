package com.example.musicapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.musicapp.databinding.ActivityHomeBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import adapter.CategoryAdapter;
import models.CategoryModel;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import android.content.Intent;
import android.view.MenuItem;

import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.musicapp.databinding.ActivityHomeBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.List;
import java.util.Map;

import adapter.CategoryAdapter;
import models.CategoryModel;

public class HomeActivity extends AppCompatActivity {
    private ActivityHomeBinding binding;
    private CategoryAdapter CategoryAdapter;
    private FirebaseAuth mAuth;
    private Button SearchNav;
    private Button PlaylistNav;
    private ImageView Logo;
    private Button Logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAuth = FirebaseAuth.getInstance();
        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.searchNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this,SearchActivity.class);
                startActivity(intent);
            }
        });

        binding.playlistNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this,PlaylistActivity.class);
                startActivity(intent);
            }
        });

        getUserData();
        getCategories();
    }

    private void getUserData() {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            // Get the user ID (UID)
            String userId = currentUser.getUid();
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            // Construct a reference to the user's document in Firestore
            DocumentReference userRef = db.collection("users").document(userId);
            // Create a new document with the userID as the document ID
            Map<String, Object> userData = new HashMap<>();
            userData.put("title", "User Profile"); // Example: Set a title for the user profile

            // Create a subcollection "playlists" within the user document
            userData.put("playlists", new ArrayList<>());

            // Add additional fields to the user's document
            userData.put("name", "John Doe");
            userData.put("email", "johndoe@example.com");
            userData.put("age", 30);

            userRef.set(new HashMap<>()) // You can set initial data if needed
                    .addOnSuccessListener(aVoid -> {
                        // Document creation successful
                        Toast.makeText(HomeActivity.this, "User document created", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        // Handle document creation failure
                        Toast.makeText(HomeActivity.this, "Failed to create user document: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
            // Now you can perform operations specific to this user
            // For example, fetch user data and update UI elements accordingly
            userRef.get().addOnSuccessListener(documentSnapshot -> {
                if (documentSnapshot.exists()) {
                    // User document exists, you can retrieve and use user data here
                    // Example: String username = documentSnapshot.getString("username");
                } else {
                    // User document does not exist
                }
            });
        }
    }
    private void getCategories() {
        FirebaseFirestore.getInstance().collection("Category")
                .get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        List<CategoryModel> categoryList = queryDocumentSnapshots.toObjects(CategoryModel.class);
                        setupCategoryRecyclerView(categoryList);
                    }
                });
    }
    private void setupCategoryRecyclerView(List<CategoryModel> categoryList) {
        CategoryAdapter = new CategoryAdapter(categoryList);
        binding.categoriesRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        binding.categoriesRecyclerView.setAdapter(CategoryAdapter);
    }

}